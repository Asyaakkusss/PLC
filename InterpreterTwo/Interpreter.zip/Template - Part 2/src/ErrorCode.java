public class ErrorCode {
    public static int
            INCORRECT_USAGE = 1,
            FILE_NOT_FOUND = 2,
            INTERPRET_ERROR = 3;

}
